<?php
/*
Plugin Name: WooCommerce Product Countdown Timer
Description: Adds a countdown timer to WooCommerce products with customizable start and end times.
Version: 1.0
Author: Shan
*/

// Add custom fields to the product edit page
function wpct_add_custom_product_fields() {
    global $post;

    woocommerce_wp_text_input(array(
        'id' => '_start_date',
        'label' => __('Start Date', 'woocommerce'),
        'placeholder' => 'YYYY-MM-DD HH:MM:SS',
        'description' => __('Enter the start date and time in the format YYYY-MM-DD HH:MM:SS.', 'woocommerce'),
        'type' => 'datetime-local',
        'desc_tip' => 'true',
    ));

    woocommerce_wp_text_input(array(
        'id' => '_end_date',
        'label' => __('End Date', 'woocommerce'),
        'placeholder' => 'YYYY-MM-DD HH:MM:SS',
        'description' => __('Enter the end date and time in the format YYYY-MM-DD HH:MM:SS.', 'woocommerce'),
        'type' => 'datetime-local',
        'desc_tip' => 'true',
    ));
}
add_action('woocommerce_product_options_general_product_data', 'wpct_add_custom_product_fields');

// Save the custom fields data
function wpct_save_custom_product_fields($post_id) {
    $start_date = isset($_POST['_start_date']) ? sanitize_text_field($_POST['_start_date']) : '';
    $end_date = isset($_POST['_end_date'])      ? sanitize_text_field($_POST['_end_date'])      : '';

    update_post_meta($post_id, '_start_date', $start_date);
    update_post_meta($post_id, '_end_date', $end_date);
}
add_action('woocommerce_process_product_meta', 'wpct_save_custom_product_fields');

// Add the countdown timer to the WooCommerce product loop.
function wpct_add_countdown_timer() {
    global $product;

    $start_date = get_post_meta($product->get_id(), '_start_date', true);
    $end_date = get_post_meta($product->get_id(), '_end_date', true);

    if ($end_date) {
        echo '<div class="product-timer" data-start-date="' . esc_attr($start_date) . '" data-end-date="' . esc_attr($end_date) . '"></div>';
    }
}
add_action('woocommerce_before_shop_loop_item_title', 'wpct_add_countdown_timer');

// Enqueue the JavaScript file
function wpct_enqueue_scripts() {
    wp_enqueue_script('wpct-countdown-timer', plugin_dir_url(__FILE__) . 'countdown-timer.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'wpct_enqueue_scripts');

// Enqueue the CSS file
function wpct_enqueue_styles() {
    wp_enqueue_style('wpct-countdown-timer-style', plugin_dir_url(__FILE__) . 'countdown-timer.css', array(), '1.0');
}
add_action('wp_enqueue_scripts', 'wpct_enqueue_styles');

?>
